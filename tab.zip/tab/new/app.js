// chapter1 Alert


// question 1

// alert("Thanks for coming for our website");


// question 2

// alert("please! don't make any violance on my website ");


// question 3

// alert("how many children do u have? \n 3 or 4?");


// question 4

// alert("r u enjoy the party with us? ");
// alert("if yes ! so give us 5 star.");


// question 5

// var new_message = "Hello... I can run JS through my web browser's console";
// alert(new_message);


// question 6

// var mama = " run ";
// alert(mama)


// question 7

please check tab file assignment 6 - Copy 


// chapter2 VARIABLES FOR STRINGS 

// question 1

// var myname = propmt"enter your name";
// alert (myname)

// question 2

// var username = "my name is raza";
// alert (username)


// question 3

// var message = "THE WORLD IS DANGEROUS NOW 4 U"
// alert(message);


// question 4

// var student1 = "he is my student "
// var student2 = "his name is Raza"
// var student3 = "he web developer"
// alert(student1)
// alert(student2)
// alert(student3)


// question 5

// var browser="pizza \n pizz \n piz \n pi \n p"
// alert(browser)


// question 6

// var email = "my email address is example@gmail.com"
// alert(email)

// question 7

// var learning = "i am trying to learn java from the book A Smarter Way To Learn JavaScript"

// question 8

// var something = "i am trying to learn java from the book A Smarter Way To Learn JavaScript"
// document.write(something)



// CHAPTER 3 VARIABLES FOR NUMBERS


// question 1

// var age = "i am 18 year old";
// alert(age)


// question 2

// var visitor = "You have visited this site 14000 times"
// alert(visitor)


// question 3

// var birthYear = "My birth year is 1540 \n but i still look very young "
// document.write(birthYear)


// question 4

// var products = "John Doe ordered 5 T-shirt(s) on XYZ Clothing store"
// document.write(products)



// CHAPTER NO.4 : VARIABLE NAMES: LEGAL & ILLEGAL


// question 1


// question 2
// var legal = ("$my_name, gender, x25, age_of_hh_head");
// var illegal = ("1my_name, @my_name, ++my_variable,~my_variable")
// alert (legal)
// alert(illegal)


// question 3

var name1 = ("A heading stating Rules for naming JS varaiables")
var name2 = ("Variable names can only contain number, $ and_.")
var name3 = ("Variables must begin with a letter, $ or _. For example $name, _name or name")
var name4 = (") Variable names are case sensitive")
var name5 = ("Variable names should not be JS keyword")
 alert(name1)
 alert(name2)
 alert(name3)
 alert(name4)


// CHAPTER NO.5 : MATH EXPRESSIONS 


// question 1

// var a = 5
// var b = 4
// var c = (a+b)
// document.write(c)


// question 2

// var a = 5
// var b = 4
// var c = (a-b)
// document.write(c)

// var a = 5
// var b = 4
// var c = (a*b)
// document.write(c)

// var a = 12
// var b = 4
// var c = (a/b)
// document.write(c)

// var a = 50
// var b = 4
// var c = (a%b)
// document.write(c)

// question 3

// var num1 = 5;
// var num2 = ++num1 
// var num3 = (num2 + 7)
// var num4 = --num3
// var num5 = (num4 / 3)
// var num6 = 
// alert(num5)
// document.write("Initial value:" + 5 + "<br>")
// document.write("Value after increment is :"+ num1 + "<br>")
// document.write("Value after increment is :"+ num1 + "<br>")
// document.write("Value after addition is:" + num3 + "<br>")
// document.write("Value after increment is :"+ num4 + "<br>")


// question 4

// var Cost_of_one_movie_ticket = 600;
// var the_number_of_buying_tickets = 5;
// var total_cost = (Cost_of_one_movie_ticket * the_number_of_buying_tickets)

// alert (total_cost)

// var head = ("table 0f 2 ")
// document.write(head + "<br>")

// question 5

// var table1 =  ("2 X 1 = 2")
// var table2 =  ("2 X 2 = 4")
// var table3 =  ("2 X 3 = 6")
// var table4 =  (" 2 X 4 = 8")
// var table5 =  (" 2 X 5 = 10")
// var table6 =  (" 2 X 6 = 12")
// var table7 =  (" 2 X 7 = 14")
// var table8 =  (" 2 X 8 = 16")
// var table9 =  ("2 X 9 = 18 ")
// var table10 = (" 2 X 10 = 20")

// document.write(table1 + "<br>")
// document.write(table2 + "<br>")
// document.write(table3 + "<br>")
// document.write(table4 + "<br>")
// document.write(table5 + "<br>")
// document.write(table6 + "<br>")
// document.write(table7 + "<br>")
// document.write(table8 + "<br>")
// document.write(table9 + "<br>")
// document.write(table10 + "<br>")


// quetion 6


// question 7

// var price1 = 650
// var item1 = 3
// var total1 = price1 * item1
// var price2 = 850
// var item2 = 2
// var total2 = price2 * item2
// var shipment = 100
// var totalcost = total1+total2+shipment
 
// document.write("price of item1:" + price1 + "<br>")
// document.write("quantity of item1:" + item1 + "<br>")
// document.write("price of item2:" + price2+ "<br>")
// document.write("quantity of item2:" + item2 + "<br>")
// document.write("shipment carges:" + shipment + "<br>")
// document.write("totalcost:" + totalcost + "<br>")


// question 8


// question 9

// var head = ("US CURRENCY IN PKR")
// document.write( head + "<br>")

// var us = 10;
// var pak = 165;
// var $total = us * pak

// document.write("currency of us dollar=:" + us + "<br>")
// document.write("currency of pakistani rupess=:" + pak + "<br>")
// document.write("us dollar into rupess=:" + $total + "<br>")

// var head = ("RIYALS CURRENCY IN PKR")
// document.write( head + "<br>")

// var riyals = 25
// var pak = 165;
// var $total2 = riyals * pak
// document.write("currency of saudi riyals=:" + us + "<br>")
// document.write("currency of pakistani rupess=:" + pak + "<br>")
// document.write("suadi riyals  into rupess=:" + $total2 + "<br>")


// question 10

// var add = 5;
// var Multiply = add * 10;
// var dividing = Multiply / 2

// alert (dividing)


// question 11

// var current = 2021;
// var birth = 1750;
// var total_age = current - birth; 

// document.write("Current year=:" + current + "<br>")
// document.write("Birth year=:" + birth + "<br>")
// document.write("My age is=:" + total_age  + "<br>")


// question 12

// question 13

// var favorite_snack = ("chocolatechip");
// var current_age = 15;
// var maximum_age = 65;
// var total = maximum_age - current_age
// // convert year into the days
// var day = total * 365
// var amount_of_snack_per_day = 3
// var total_snack = day * amount_of_snack_per_day

// document.write("favorite snack=:" + favorite_snack + "<br>")
// document.write("current age=:" + current_age + "<br>")
// document.write("maximum age=:" + maximum_age  + "<br>")
// document.write("remaining year=:" + maximum_age - current_age + "<br>")
// document.write("year converted into days=:" + day + "<br>")
// document.write("amount of snack as per day=:" + amount_of_snack_per_day + "<br>")
// document.write("total snack =:" + total_snack + "<br>")



// CHAPTER 6-9 : MATH EXPRESSIONS 

// question 1

// var result = ("Result:")

// var a = 10 
// document.write("The value of a is =:" + result + "<br>")

// document.write("................:" + "<br>")

// var b = ++a 
// document.write("The value of ++a is =:" + b + "<br>")
// document.write("The value of a is =:" + b + "<br>")

// document.write("............" + "<br>")

// var b = a++ 
// document.write("The value of a++ is =:" + b + "<br>")
// document.write("The value of a is =:" + 12 + "<br>")

// document.write("............"  + "<br>")

// var c = --a
// document.write("The value of --a is =:" + c + "<br>")
// document.write("The value of a is =:" + c + "<br>")

// var d = a--
// document.write("The value of a-- is =:" + d + "<br>")
// document.write("now value of a is =:" + 10 + "<br>")
// alert (d)


// question 2

// var a = 2;
// var b = 1;
// var num1 = --a;
// var num2 = num1 - --b;
// var num3 = num2 + ++b;
// var num4 = num3 + b--;

// document.write("The value of a is =:" + a + "<br>") 
// document.write("The value of b is =:" + b + "<br>") 
// document.write("The value of num1 is =:" + num1 + "<br>") 
// document.write("The value of num2 is =:" + num2 + "<br>") 
// document.write("The value of num3 is =:" + num3 + "<br>") 
// document.write("The value of num4 is =:" + num4 + "<br>")


// question 3

// var username = prompt ("Enter your Name")
// document.write ( username +"<br>")

// var jab = ("wellcome to the new world")
// document.write ( jab +"<br>")


// question 6

// var head = ("subject..........totalmark.........obtainedmark..........percentage")

// document.write ( head +"<br>")
// var eng = ("english............100.......................54..........................54%")
// document.write (eng +"<br>")
// var  Math= ("math................100.......................54..........................54%")
// document.write (Math +"<br>")
// var urdu = ("Urdu...............100.......................54..........................54%")
// document.write (urdu +"<br>")
// var total = ("........................300.......................156..........................52%")

// document.write (total +"<br>")



// CHAPTER 6-9 : USER INPUT & CONDITIONAL STATEMENT

// question 1

//  var city = prompt("where do u live");
//  if (city === "karachi")
// {document.write ("Welcome to city of lights")};


// question 2

// var gender = prompt ("enter your gender")
// if (gender == male) {alert ("Good Morning Sir")}
// else if (gender == female) {alert ("Good Morning Ma’am")}
// else {alert("enter your correct gender")}


// question 4

// var fuel = prompt("enter your fuel") 
// if (fuel == 0.25) {alert ("your fuel is ok")}
// else if (age >0.25) {alert ("Please refill the fuel in your car")}
// else {alert("enter your correct fuel")}


// question 4

// a.
//  var a = 4;
// if (++a === 5){
// alert("given condition for variable a is true");
// }

// a.
// var b = 82;
// if (b++ === 83){
// alert("given condition for variable b is true");
// }

// c.
// var c = 12;
// if (c++ === 13){
// alert("condition 1 is true");
// }
// if (c === 13){
// alert("condition 2 is true");
// }
// if (++c < 14){
// alert("condition 3 is true");
// }
// if(c === 14){
// alert("condition 4 is true");
// }

// d.
// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost){
// alert("The cost equals");
// }

// e.
// if (true){
//  alert("True");
// }
// if (false){
// alert("False");
// }

// f.
// if("car" < "cat"){
// alert("car is smaller than cat");
// }


// question 6


// var Math= +prompt("Enter your Math Mark");
// var English= +prompt("Enter your English Mark");
// var Chemistry= +prompt("Enter your Chemistry Mark");
// var Physics= +prompt("Enter your Physics Mark");
// var Computer= +prompt("Enter your Computer Mark");
// var Urdu= +prompt("Enter your Urdu Mark");
// var Total_marks= parseInt(Math) + parseInt(English) + parseInt(Chemistry) + parseInt(Physics) + parseInt(Computer) + parseInt(Urdu);
// var Percentage = Total_marks * 100/600;

// document.write ("Your Math Mark  is :" + Math+"<br>")
// document.write ("Your English Mark is :" + English +"<br>")
// document.write ("Your Chemistry Mark is :" + Chemistry +"<br>")
// document.write ("Your Physics Mark is :" + Physics +"<br>")
// document.write ("Your Computer Mark is :" + Computer +"<br>")
// document.write ("Your Urdu Mark is :" + Urdu +"<br>")
// document.write ("Your Total Mark is :" + Total_marks +"<br>")
// document.write ("Your Percentage is :" + Percentage +"<br>")

// if (Percentage >= 80) {document.write ("your grade is : A-1")}
// else if (Percentage >= 70) {document.write ("your grade is : A")}
// else if (Percentage >= 60) {document.write ("your grade is : B")}
// else if (Percentage >= 50) {document.write ("your grade is : C")}
// else if (Percentage >= 40) {document.write ("your grade is : D")}
// else if (Percentage >= 33) {document.write ("your grade is : E")}
// else if (Percentage >= 33) {document.write ("your grade is : FAIL ")}
// else {document.write("enter your correct no. of subject")}


// question 7
// var userinput = prompt("enter any no. to identify ")
// if (guess ==5) {alert("bingo")}
// else if (guess ==1) {document.write ("“Close enough to the correct answer")}
// else {document.write("enter your correct no.")}


// question 9
// var userinput = prompt("enter any no. to identify ")
// if (userinput%2 ==0) {document.write (userinput+ "even")}
// else {document.write(userinput+ "odd")}


// question 10

// var temperature = prompt("enter temperature of your area ")
// if (temperature >= 40) {document.write ("It is too hot outside")}
// else if (temperature >= 30) {document.write ("The Weather today is Normal")}
// else if (temperature >= 20) {document.write ("Today’s Weather is cool")}
// else if (temperature >= 10) {document.write ("“OMG! Today’s weather is so Cool")}
// else {document.write("enter your correct temperature of your area ")}



// CHAPTER 12-13 : IF…ELSE & ELSE IF STATEMENT, TESTING SET OF CONDITIONS 

// question 3

// var userinput = prompt("enter any no.")
// if (userinput >0 ) {document.write ("positve no.")}
// else if (userinput < 0 ) {document.write ("negative no.")}
// else if (userinput ==0 ) {document.write ("opps" )}
// else {document.write ("enter any no. again")}


// question 6

// var greeting;
// var hour = 13;
// if (hour < 18) {
// greeting = "Good day";}
// else{greeting = "Good evening";}


// question 7

// var time = prompt("enter any no. from 0 to 2359")
// if (time >=0000 && time<=1200 ) {document.write ("Good Morning")}
// else if (time >=1200 && time<=1700 ) {document.write ("Good afternoon")}
// else if (time >=1700 && time<=2100 ) {document.write ("Good evening")}
// else if (time >=2100 && time<=2359 ) {document.write ("Good night")}
// else {document.write ("enter any no. again")}


